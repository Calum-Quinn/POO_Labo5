package src.matrix.operations;

/**
 * @author Calum Quinn
 * @author Dylan Ramos
 */
public abstract class Operation {
    public abstract int calculate(int op1, int op2);

    public abstract String toString();
}
